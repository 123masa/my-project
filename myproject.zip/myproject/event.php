<?php
// Language switching logic
session_start();
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
}

// Set default language to English and include the language file
$lang_file = 'lang_en.php';
if (isset($_SESSION['lang']) && $_SESSION['lang'] == 'ar') {
    $lang_file = 'lang_ar.php';
}
include($lang_file);

// Database connection
$pdo = new PDO('mysql:host=localhost;dbname=city_events;charset=utf8mb4', 'root', '');
$id = $_GET["id"];
?>

<!DOCTYPE html>
<html lang="<?php echo $lang['html_lang']; ?>" dir="<?php echo $lang['html_dir']; ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $lang['event_details_title']; ?> - <?php echo $lang['page_title']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css">
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
            <div class="container">
                <a class="navbar-brand" href="index.php">
                    <img src="img/logo.png" alt="<?php echo $lang['navbar_brand']; ?>" width="40" height="40" class="d-inline-block align-text-top me-2"> <?php echo $lang['navbar_brand']; ?>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php"><?php echo $lang['nav_home']; ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="events.php"><?php echo $lang['nav_events']; ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.php"><?php echo $lang['nav_about']; ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php"><?php echo $lang['nav_contact']; ?></a>
                        </li>
                        <li class="nav-item d-flex align-items-center lang-switcher ms-lg-3">
                            <a href="event.php?id=<?php echo $id; ?>&lang=ar" class="nav-link p-1 mx-1"><img src="https://flagcdn.com/w40/sy.png" alt="Arabic"></a>
                            <a href="event.php?id=<?php echo $id; ?>&lang=en" class="nav-link p-1 mx-1"><img src="https://flagcdn.com/w40/us.png" alt="English"></a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <main class="container my-5">
        <div id="eventDetails">
            <?php
            $stmt = $pdo->query("SELECT * FROM evente where id = $id");
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                // Use appropriate language fields based on current language
                $title = (isset($_SESSION['lang']) && $_SESSION['lang'] == 'ar') ? $row['title'] : $row['title_en'];
                $description = (isset($_SESSION['lang']) && $_SESSION['lang'] == 'ar') ? $row['description'] : $row['description_en'];
                $category = (isset($_SESSION['lang']) && $_SESSION['lang'] == 'ar') ? $row['category'] : $row['category_en'];
                $location = (isset($_SESSION['lang']) && $_SESSION['lang'] == 'ar') ? $row['location'] : $row['location_en'];

                echo   "
        <div class='row'>
            <div class='col-md-8'>
                <img src='" . $row['image'] . "' class='img-fluid rounded mb-4' >
                <h1>" . $title . "</h1>
                <div class='d-flex align-items-center mb-3'>
                    <span class='badge bg-primary me-2'>" . $category . "</span>
                    <span class='text-muted'><i class='far fa-calendar-alt me-1'></i>" . $row['event_date'] . "</span>
                
                    <span class='text-muted ms-3'><i class='fas fa-map-marker-alt me-1'></i>" . $location . "</span>
                </div>
                <p>" . $description . "</p>
                
               
            </div>
            <div class='col-md-4'>
                <div class='card'>
                    <div class='card-header'>
                        <h5 class='card-title mb-0'>" . $lang['event_info'] . "</h5>
                    </div>
                    <div class='card-body'>
                        <p><strong>" . $lang['event_date'] . ":</strong> " . $row['event_date'] . "</p>
                    
                        <p><strong>" . $lang['event_location'] . ":</strong> " . $location . "</p>
                        <p><strong>" . $lang['event_category'] . ":</strong> " . $category . "</p>
                    </div>
                </div>
                
                <div class='card mt-4'>
                    <div class='card-header'>
                        <h5 class='card-title mb-0'>" . $lang['related_events'] . "</h5>
                    </div>
                
                   
                </div>
            </div>
        </div>
    ";
            }

            ?>
        </div>
    </main>

    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5><?php echo $lang['navbar_brand']; ?></h5>
                    <p><?php echo $lang['footer_platform_desc']; ?></p>
                </div>
                <div class="col-md-4">
                    <h5><?php echo $lang['footer_quick_links']; ?></h5>
                    <ul class="list-unstyled">
                        <li><a href="index.php" class="text-white"><?php echo $lang['nav_home']; ?></a></li>
                        <li><a href="events.php" class="text-white"><?php echo $lang['nav_events']; ?></a></li>
                        <li><a href="about.php" class="text-white"><?php echo $lang['nav_about']; ?></a></li>
                        <li><a href="contact.php" class="text-white"><?php echo $lang['nav_contact']; ?></a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5><?php echo $lang['footer_contact_us']; ?></h5>
                    <p><?php echo $lang['footer_email']; ?></p>
                    <p><?php echo $lang['footer_phone']; ?></p>
                    <div class="social-links">
                        <a href="#" class="text-white me-2"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="text-white me-2"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-white me-2"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <hr>
            <div class="text-center">
                <p class="mb-0"><?php echo $lang['footer_copyright']; ?></p>
                <p><?php echo $lang['footer_project_info']; ?></p>
                <p><?php echo $lang['footer_team_members']; ?></p>
            </div>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

</body>

</html>