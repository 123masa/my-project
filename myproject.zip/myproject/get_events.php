<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "city_events";

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Determine language
$lang = isset($_SESSION['lang']) ? $_SESSION['lang'] : 'en';

// Get events from database
$stmt = $pdo->prepare("SELECT * FROM evente ORDER BY event_date ASC");
$stmt->execute();
$events = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Format events for JavaScript
$formattedEvents = [];
foreach ($events as $event) {
    $formattedEvents[] = [
        'id' => $event['id'],
        'title' => $lang === 'ar' ? $event['title'] : $event['title_en'],
        'description' => $lang === 'ar' ? $event['description'] : $event['description_en'],
        'date' => $event['event_date'],
        'location' => $lang === 'ar' ? $event['location'] : $event['location_en'],
        'category' => $lang === 'ar' ? $event['category'] : $event['category_en'],
        'image' => $event['image'],
        'featured' => $event['id'] <= 3 // First 3 events are featured
    ];
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($formattedEvents);
?>