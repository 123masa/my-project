<?php 
// Language switching logic
session_start();
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
}

// Set default language to English and include the language file
$lang_file = 'lang_en.php';
if (isset($_SESSION['lang']) && $_SESSION['lang'] == 'ar') {
    $lang_file = 'lang_ar.php';
}
include($lang_file);
?>
<!DOCTYPE html>
<html lang="<?php echo $lang['html_lang']; ?>" dir="<?php echo $lang['html_dir']; ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $lang['nav_contact']; ?> - <?php echo $lang['page_title']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css">
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
            <div class="container">
                <a class="navbar-brand" href="index.php">
                    <img src="img/logo.png" alt="<?php echo $lang['navbar_brand']; ?>" width="40" height="40" class="d-inline-block align-text-top me-2"> <?php echo $lang['navbar_brand']; ?>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php"><?php echo $lang['nav_home']; ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="events.php"><?php echo $lang['nav_events']; ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.php"><?php echo $lang['nav_about']; ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="contact.php"><?php echo $lang['nav_contact']; ?></a>
                        </li>
                        <li class="nav-item d-flex align-items-center lang-switcher ms-lg-3">
                            <a href="contact.php?lang=ar" class="nav-link p-1 mx-1"><img src="https://flagcdn.com/w40/sy.png" alt="Arabic"></a>
                            <a href="contact.php?lang=en" class="nav-link p-1 mx-1"><img src="https://flagcdn.com/w40/us.png" alt="English"></a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <main class="container my-5">
        <h1 class="text-center mb-4"><?php echo $lang['contact_page_title']; ?></h1>

        <div class="row">
            <div class="col-md-8">
                <!-- Success/Error Messages -->
                <div id="formMessages"></div>

                <!-- Contact Form -->
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="card-title mb-0"><?php echo $lang['send_message']; ?></h5>
                    </div>
                    <div class="card-body">
                        <form id="contactForm">
                            <div class="mb-3">
                                <label for="name" class="form-label"><?php echo $lang['full_name']; ?></label>
                                <input type="text" class="form-control" id="name" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label"><?php echo $lang['email']; ?></label>
                                <input type="email" class="form-control" id="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="subject" class="form-label"><?php echo $lang['subject']; ?></label>
                                <select class="form-select" id="subject">
                                    <option value="استفسار"><?php echo $lang['subject_general']; ?></option>
                                    <option value="مقترح"><?php echo $lang['subject_suggestion']; ?></option>
                                    <option value="شكوى"><?php echo $lang['subject_complaint']; ?></option>
                                    <option value="فعالية"><?php echo $lang['subject_event']; ?></option>
                                    <option value="تعاون"><?php echo $lang['subject_cooperation']; ?></option>
                                    <option value="أخرى"><?php echo $lang['subject_other']; ?></option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="message" class="form-label"><?php echo $lang['message']; ?></label>
                                <textarea class="form-control" id="message" rows="5" required></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary"><?php echo $lang['send_button']; ?></button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <!-- معلومات التواصل -->
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="card-title mb-0"><?php echo $lang['contact_info']; ?></h5>
                    </div>
                    <div class="card-body">
                        <p><i class="fas fa-envelope me-2 text-primary"></i> <strong><?php echo $lang['email']; ?>:</strong> <?php echo str_replace('البريد الإلكتروني: ', '', $lang['footer_email']); ?></p>
                        <p><i class="fas fa-phone me-2 text-primary"></i> <strong><?php echo ($_SESSION['lang'] == 'en') ? 'Phone' : 'الهاتف'; ?>:</strong> <?php echo str_replace('الهاتف: ', '', str_replace('Phone: ', '', $lang['footer_phone'])); ?></p>
                        <p><i class="fas fa-map-marker-alt me-2 text-primary"></i> <strong><?php echo $lang['address']; ?>:</strong> <?php echo ($_SESSION['lang'] == 'en') ? 'Syria - Damascus - Umayyad Square' : 'سوريا - دمشق - ساحة الأمويين'; ?></p>
                    </div>
                </div>

                <!-- وسائل التواصل الاجتماعي -->
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="card-title mb-0"><?php echo $lang['social_media']; ?></h5>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-around">
                            <a href="#" class="btn btn-outline-primary btn-social">
                                <i class="fab fa-facebook-f"></i>
                            </a>
                            <a href="#" class="btn btn-outline-primary btn-social">
                                <i class="fab fa-twitter"></i>
                            </a>
                            <a href="#" class="btn btn-outline-primary btn-social">
                                <i class="fab fa-instagram"></i>
                            </a>
                            <a href="#" class="btn btn-outline-primary btn-social">
                                <i class="fab fa-linkedin-in"></i>
                            </a>
                        </div>
                    </div>
                </div>

                <!-- أوقات العمل -->
                <div class="card mt-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="card-title mb-0"><?php echo $lang['working_hours']; ?></h5>
                    </div>
                    <div class="card-body">
                        <p><?php echo $lang['working_days']; ?></p>
                        <p><?php echo $lang['friday_closed']; ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- خريطة الموقع -->
        <div class="card mt-5">
            <div class="card-header bg-primary text-white">
                <h5 class="card-title mb-0"><?php echo $lang['location_map']; ?></h5>
            </div>
            <div class="card-body">
                <div class="ratio ratio-16x9">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3621.231831553158!2d46.67278227599606!3d24.831122277956!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e2ee3e9c2e7c2b5%3A0x2d3d2e3d3e3d3e3d!2sRiyadh%2C%20Saudi%20Arabia!5e0!3m2!1sen!2sus!4v1633456789012!5m2!1sen!2sus"
                        width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>
            </div>
        </div>
    </main>

    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5><?php echo $lang['navbar_brand']; ?></h5>
                    <p><?php echo $lang['footer_platform_desc']; ?></p>
                </div>
                <div class="col-md-4">
                    <h5><?php echo $lang['footer_quick_links']; ?></h5>
                    <ul class="list-unstyled">
                        <li><a href="index.php" class="text-white"><?php echo $lang['nav_home']; ?></a></li>
                        <li><a href="events.php" class="text-white"><?php echo $lang['nav_events']; ?></a></li>
                        <li><a href="about.php" class="text-white"><?php echo $lang['nav_about']; ?></a></li>
                        <li><a href="contact.php" class="text-white"><?php echo $lang['nav_contact']; ?></a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5><?php echo $lang['footer_contact_us']; ?></h5>
                    <p><?php echo $lang['footer_email']; ?></p>
                    <p><?php echo $lang['footer_phone']; ?></p>
                    <div class="social-links">
                        <a href="#" class="text-white me-2"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="text-white me-2"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-white me-2"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <hr>
            <div class="text-center">
                <p class="mb-0"><?php echo $lang['footer_copyright']; ?></p>
                <p><?php echo $lang['footer_project_info']; ?></p>
                <p><?php echo $lang['footer_team_members']; ?></p>
            </div>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <script src="js/main.js"></script>
</body>

</html>