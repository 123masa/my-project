<?php 
// 1. Start session to remember language choice
session_start();

// 2. Language switching logic
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
}

// 3. Set default language to English and include the language file
$lang_file = 'lang_en.php';
if (isset($_SESSION['lang']) && $_SESSION['lang'] == 'ar') {
    $lang_file = 'lang_ar.php';
}
include($lang_file);

// 4. Database connection
$pdo = new PDO('mysql:host=localhost;dbname=city_events;charset=utf8mb4','root', ''); 
?>
<!DOCTYPE html>
<html lang="<?php echo $lang['html_lang']; ?>" dir="<?php echo $lang['html_dir']; ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $lang['page_title']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css">
    <style>
        /* Optional: better alignment for flags in the navbar */
        .lang-switcher a { display: inline-block; vertical-align: middle; }
        .lang-switcher img { width: 25px; height: auto; }
    </style>
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
            <div class="container">
                <a class="navbar-brand" href="index.php">
                    <img src="img/logo.png" alt="<?php echo $lang['navbar_brand']; ?> Logo" width="40" height="40" class="d-inline-block align-text-top me-2"> <?php echo $lang['navbar_brand']; ?>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link active" href="index.php"><?php echo $lang['nav_home']; ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="events.php"><?php echo $lang['nav_events']; ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.php"><?php echo $lang['nav_about']; ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php"><?php echo $lang['nav_contact']; ?></a>
                        </li>
                         <li class="nav-item d-flex align-items-center lang-switcher ms-lg-3">
                            <a href="index.php?lang=ar" class="nav-link p-1 mx-1"><img src="https://flagcdn.com/w40/sy.png" alt="Arabic"></a>
                            <a href="index.php?lang=en" class="nav-link p-1 mx-1"><img src="https://flagcdn.com/w40/us.png" alt="English"></a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <main class="container my-5">
        <section class="hero-section mb-5">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h1 class="display-4 fw-bold text-primary"><?php echo $lang['hero_title']; ?></h1>
                    <p class="lead"><?php echo $lang['hero_subtitle']; ?></p>
                    <a href="events.php" class="btn btn-primary btn-lg mt-3"><?php echo $lang['hero_button']; ?></a>
                </div>
                <div class="col-md-6">
                    <div id="eventsCarousel" class="carousel slide" data-bs-ride="carousel">
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img src="img/event1.jpg" class="d-block w-100 rounded" alt="<?php echo $lang['carousel_alt_1']; ?>">
                            </div>
                            <div class="carousel-item">
                                <img src="img/event2.jpg" class="d-block w-100 rounded" alt="<?php echo $lang['carousel_alt_2']; ?>">
                            </div>
                            <div class="carousel-item">
                                <img src="img/event3.jpg" class="d-block w-100 rounded" alt="<?php echo $lang['carousel_alt_3']; ?>">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="featured-events mb-5">
            <h2 class="text-center mb-4"><?php echo $lang['featured_events_title']; ?></h2>
            <div class="row" id="featuredEvents">
                <?php
                // Get events data with appropriate language fields
                $stmt = $pdo->query("SELECT * FROM evente"); 
                while ( $row = $stmt->fetch(PDO::FETCH_ASSOC) ) { 
                    // Use appropriate language fields based on current language
                    $title = (isset($_SESSION['lang']) && $_SESSION['lang'] == 'ar') ? $row['title'] : $row['title_en'];
                    $category = (isset($_SESSION['lang']) && $_SESSION['lang'] == 'ar') ? $row['category'] : $row['category_en'];
                    $location = (isset($_SESSION['lang']) && $_SESSION['lang'] == 'ar') ? $row['location'] : $row['location_en'];
                    
                    echo "
                        <div class='col-md-4 mb-4'>
                            <div class='card h-100 event-card' data-id=".$row['id'].">
                            <a href='event.php?id=".$row['id']."'>   <img src=".$row['image']." class='card-img-top' alt='".$title."'></a>
                                <div class='card-body'>
                                    <span class='badge bg-primary mb-2'>".$category."</span>
                                    <h5 class='card-title'>".$title."</h5>
                                </div>
                                <div class='card-footer bg-transparent'>
                                    <small class='text-muted'><i class='far fa-calendar-alt me-1'></i> ".$row['event_date']."| <i class='far fa-clock me-1'></i></small>
                                    <br>
                                    <small class='text-muted'><i class='fas fa-map-marker-alt me-1'></i> ".$location."</small>
                                </div>
                            </div>
                        </div>
                    ";
                } 
                ?>
            </div>
        </section>

     
        <section class="mb-5">
            <h2 class="text-center mb-4"><?php echo $lang['team_title']; ?></h2>
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="card text-center h-100">
                        <img src="img/y3.jpg" class="card-img-top rounded-circle w-50 mx-auto mt-3" alt="Team Member">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $lang['team_member_1_name']; ?></h5>
                            <p class="card-text"><?php echo $lang['team_member_1_role']; ?></p>
                            <p class="text-muted"><?php echo $lang['team_member_1_desc']; ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card text-center h-100">
                        <img src="img/y2.jpg" class="card-img-top rounded-circle w-50 mx-auto mt-3" alt="Team Member">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $lang['team_member_2_name']; ?></h5>
                            <p class="card-text"><?php echo $lang['team_member_2_role']; ?></p>
                            <p class="text-muted"><?php echo $lang['team_member_2_desc']; ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card text-center h-100">
                        <img src="img/y1.jpg" class="card-img-top rounded-circle w-50 mx-auto mt-3" alt="Team Member">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $lang['team_member_3_name']; ?></h5>
                            <p class="card-text"><?php echo $lang['team_member_3_role']; ?></p>
                            <p class="text-muted"><?php echo $lang['team_member_3_desc']; ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5><?php echo $lang['navbar_brand']; ?></h5>
                    <p><?php echo $lang['footer_platform_desc']; ?></p>
                </div>
                <div class="col-md-4">
                    <h5><?php echo $lang['footer_quick_links']; ?></h5>
                    <ul class="list-unstyled">
                        <li><a href="index.php" class="text-white"><?php echo $lang['nav_home']; ?></a></li>
                        <li><a href="events.php" class="text-white"><?php echo $lang['nav_events']; ?></a></li>
                        <li><a href="about.php" class="text-white"><?php echo $lang['nav_about']; ?></a></li>
                        <li><a href="contact.php" class="text-white"><?php echo $lang['nav_contact']; ?></a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5><?php echo $lang['footer_contact_us']; ?></h5>
                    <p><?php echo $lang['footer_email']; ?></p>
                    <p><?php echo $lang['footer_phone']; ?></p>
                    <div class="social-links">
                        <a href="#" class="text-white me-2"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="text-white me-2"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-white me-2"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <hr>
            <div class="text-center">
                <p class="mb-0"><?php echo $lang['footer_copyright']; ?></p>
                <p><?php echo $lang['footer_project_info']; ?></p>
                <p><?php echo $lang['footer_team_members']; ?></p>
            </div>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <script src="js/main_new.js"></script>

</body>

</html>