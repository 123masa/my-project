<?php
$lang = [
    // General
    'html_lang' => 'ar',
    'html_dir' => 'rtl',
    'page_title' => 'دليل فعاليات المدينة',

    // Navbar
    'navbar_brand' => 'دليل فعاليات المدينة',
    'nav_home' => 'الرئيسية',
    'nav_events' => 'الفعاليات',
    'nav_about' => 'عن الدليل',
    'nav_contact' => 'اتصل بنا',

    // Hero Section
    'hero_title' => 'اكتشف الفعاليات القادمة في مدينتك',
    'hero_subtitle' => 'دليلك الشامل لأهم الفعاليات الثقافية، الرياضية، الفنية والترفيهية في المدينة',
    'hero_button' => 'استعرض جميع الفعاليات',
    'carousel_alt_1' => 'فعالية ثقافية',
    'carousel_alt_2' => 'فعالية رياضية',
    'carousel_alt_3' => 'فعالية فنية',

    // Featured Events
    'featured_events_title' => 'فعاليات بارزة هذا الأسبوع',

    // Team Section
    'team_title' => 'فريق العمل',
    'team_member_1_name' => 'اسراء الجسري',
    'team_member_1_role' => 'مطور الواجهة الأمامية',
    'team_member_1_desc' => 'مسؤول عن تصميم وتطوير واجهة المستخدم وتجربة المستخدم.',
    'team_member_2_name' => 'اسراء الجسري',
    'team_member_2_role' => 'مصمم جرافيك',
    'team_member_2_desc' => 'مسؤول عن التصميم البصري والشعارات والهوية البصرية للمنصة.',
    'team_member_3_name' => 'عامر سليمان إدريس',
    'team_member_3_role' => 'مدير المحتوى',
    'team_member_3_desc' => 'مسؤول عن مراجعة المحتوى وتحديث معلومات الفعاليات والأنشطة.',

    // Events Page
    'events_page_title' => 'جميع الفعاليات',
    'search_placeholder' => 'ابحث عن فعالية...',
    'all_categories' => 'جميع التصنيفات',
    'category_culture' => 'ثقافة',
    'category_sports' => 'رياضة',
    'category_music' => 'موسيقى',
    'category_education' => 'تعليم',
    'category_entertainment' => 'ترفيه',
    'pagination_previous' => 'السابق',
    'pagination_next' => 'التالي',

    // Event Details Page
    'event_details_title' => 'تفاصيل الفعالية',
    'event_info' => 'معلومات الفعالية',
    'event_date' => 'التاريخ',
    'event_location' => 'المكان',
    'event_category' => 'التصنيف',
    'related_events' => 'فعاليات ذات صلة',

    // About Page
    'about_page_title' => 'عن دليل فعاليات المدينة',
    'our_vision' => 'رؤيتنا',
    'vision_text' => 'أن نكون المنصة الأولى والمرجع الأساسي لجميع الفعاليات والأنشطة في المدينة، نسعى لتعزيز الحياة الثقافية والاجتماعية من خلال توفير معلومات شاملة ودقيقة عن جميع الأحداث.',
    'our_mission' => 'رسالتنا',
    'mission_text' => 'تسهيل الوصول إلى المعلومات حول الفعاليات المختلفة، ودعم المنظمين في الترويج لفعالياتهم، وتمكين أفراد المجتمع من المشاركة في الأنشطة التي تثرى حياتهم وتوسع مداركهم.',
    'guide_policies' => 'سياسات الدليل',
    'event_criteria' => 'معايير إضافة الفعاليات',
    'privacy_policy' => 'سياسة الخصوصية',
    'how_to_add_event' => 'كيفية إضافة فعالية',
    'privacy_text' => 'نحن نحترم خصوصيتك ونسعى لحماية بياناتك الشخصية. لا نشارك معلوماتك مع أطراف ثالثة دون موافقتك إلا في الحالات التي يتطلبها القانون.',

    // Contact Page
    'contact_page_title' => 'اتصل بنا',
    'send_message' => 'أرسل رسالة',
    'full_name' => 'الاسم الكامل',
    'email' => 'البريد الإلكتروني',
    'subject' => 'الموضوع',
    'message' => 'الرسالة',
    'send_button' => 'إرسال الرسالة',
    'contact_info' => 'معلومات التواصل',
    'address' => 'العنوان',
    'social_media' => 'وسائل التواصل الاجتماعي',
    'working_hours' => 'أوقات العمل',
    'location_map' => 'خريطة الموقع',
    'subject_general' => 'استفسار عام',
    'subject_suggestion' => 'مقترح',
    'subject_complaint' => 'شكوى',
    'subject_event' => 'إضافة فعالية',
    'subject_cooperation' => 'فرص تعاون',
    'subject_other' => 'أخرى',
    'working_days' => 'السبت - الخميس: 8:00 ص - 6:00 م',
    'friday_closed' => 'الجمعة: مغلق',

    // Admin Panel
    'admin_login' => 'تسجيل الدخول',
    'username' => 'اسم المستخدم',
    'password' => 'كلمة المرور',
    'login_button' => 'دخول',
    'login_error' => '❌ اسم المستخدم أو كلمة المرور غير صحيحة.',
    'add_new_event' => 'إضافة فعالية جديدة',
    'event_title' => 'عنوان الفعالية',
    'event_description' => 'وصف الفعالية',
    'event_image' => 'صورة الفعالية',
    'add_button' => 'إضافة',
    'cancel_button' => 'إلغاء',

    // Footer
    'footer_platform_desc' => 'منصة شاملة للتعريف بجميع الفعاليات والأنشطة في المدينة.',
    'footer_quick_links' => 'روابط سريعة',
    'footer_contact_us' => 'تواصل معنا',
    'footer_email' => 'البريد الإلكتروني: esratr@gmail.com',
    'footer_phone' => 'الهاتف: 0945452133',
    'footer_copyright' => '© 2025 دليل فعاليات المدينة. جميع الحقوق محفوظة.',
    'footer_project_info' => 'تم إنشاء هذا الموقع كجزء من مشروع مقرر BWP401',
    'footer_team_members' => 'فريق العمل: اسراء الجسري/لين ديروان /ماسة الحمصي/ليلاس خباز/عامر سليمان إدريس',
];
