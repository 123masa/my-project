<?php
$lang = [
    // General
    'html_lang' => 'en',
    'html_dir' => 'ltr',
    'page_title' => 'City Events Guide',

    // Navbar
    'navbar_brand' => 'City Events Guide',
    'nav_home' => 'Home',
    'nav_events' => 'Events',
    'nav_about' => 'About',
    'nav_contact' => 'Contact Us',

    // Hero Section
    'hero_title' => 'Discover Upcoming Events in Your City',
    'hero_subtitle' => 'Your comprehensive guide to the most important cultural, sports, artistic, and entertainment events in the city.',
    'hero_button' => 'Browse All Events',
    'carousel_alt_1' => 'Cultural Event',
    'carousel_alt_2' => 'Sports Event',
    'carousel_alt_3' => 'Art Event',

    // Featured Events
    'featured_events_title' => 'Featured Events This Week',

    // Team Section
    'team_title' => 'Our Team',
    'team_member_1_name' => 'Israa Al Jesri',
    'team_member_1_role' => 'Frontend Developer',
    'team_member_1_desc' => 'Responsible for designing and developing the user interface and user experience.',
    'team_member_2_name' => 'Israa Al Jesri',
    'team_member_2_role' => 'Graphic Designer',
    'team_member_2_desc' => 'Responsible for visual design, logos, and the platform\'s visual identity.',
    'team_member_3_name' => 'Amer Suleiman Idris',
    'team_member_3_role' => 'Content Manager',
    'team_member_3_desc' => 'Responsible for content review and updating event and activity information.',

    // Events Page
    'events_page_title' => 'All Events',
    'search_placeholder' => 'Search for an event...',
    'all_categories' => 'All Categories',
    'category_culture' => 'Culture',
    'category_sports' => 'Sports',
    'category_music' => 'Music',
    'category_education' => 'Education',
    'category_entertainment' => 'Entertainment',
    'pagination_previous' => 'Previous',
    'pagination_next' => 'Next',

    // Event Details Page
    'event_details_title' => 'Event Details',
    'event_info' => 'Event Information',
    'event_date' => 'Date',
    'event_location' => 'Location',
    'event_category' => 'Category',
    'related_events' => 'Related Events',

    // About Page
    'about_page_title' => 'About City Events Guide',
    'our_vision' => 'Our Vision',
    'vision_text' => 'To be the first platform and main reference for all events and activities in the city, we strive to enhance cultural and social life by providing comprehensive and accurate information about all events.',
    'our_mission' => 'Our Mission',
    'mission_text' => 'Facilitating access to information about various events, supporting organizers in promoting their events, and enabling community members to participate in activities that enrich their lives and broaden their horizons.',
    'guide_policies' => 'Guide Policies',
    'event_criteria' => 'Event Addition Criteria',
    'privacy_policy' => 'Privacy Policy',
    'how_to_add_event' => 'How to Add an Event',
    'privacy_text' => 'We respect your privacy and strive to protect your personal data. We do not share your information with third parties without your consent except in cases required by law.',

    // Contact Page
    'contact_page_title' => 'Contact Us',
    'send_message' => 'Send Message',
    'full_name' => 'Full Name',
    'email' => 'Email',
    'subject' => 'Subject',
    'message' => 'Message',
    'send_button' => 'Send Message',
    'contact_info' => 'Contact Information',
    'address' => 'Address',
    'social_media' => 'Social Media',
    'working_hours' => 'Working Hours',
    'location_map' => 'Location Map',
    'subject_general' => 'General Inquiry',
    'subject_suggestion' => 'Suggestion',
    'subject_complaint' => 'Complaint',
    'subject_event' => 'Add Event',
    'subject_cooperation' => 'Cooperation Opportunities',
    'subject_other' => 'Other',
    'working_days' => 'Saturday - Thursday: 8:00 AM - 6:00 PM',
    'friday_closed' => 'Friday: Closed',

    // Admin Panel
    'admin_login' => 'Login',
    'username' => 'Username',
    'password' => 'Password',
    'login_button' => 'Login',
    'login_error' => '❌ Username or password is incorrect.',
    'add_new_event' => 'Add New Event',
    'event_title' => 'Event Title',
    'event_description' => 'Event Description',
    'event_image' => 'Event Image',
    'add_button' => 'Add',
    'cancel_button' => 'Cancel',

    // Footer
    'footer_platform_desc' => 'A comprehensive platform to introduce all events and activities in the city.',
    'footer_quick_links' => 'Quick Links',
    'footer_contact_us' => 'Contact Us',
    'footer_email' => 'Email: esratr@gmail.com',
    'footer_phone' => 'Phone: 0945452133',
    'footer_copyright' => '© 2025 City Events Guide. All rights reserved.',
    'footer_project_info' => 'This website was created as part of the BWP401 course project.',
    'footer_team_members' => 'Team Members: Israa Al Jesri/Leen Derwan/Masa Al Homsi/Lilas Khabbaz/Amer Suleiman Idris',
];
?>