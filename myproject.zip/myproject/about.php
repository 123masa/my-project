<?php 
// Language switching logic
session_start();
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
}

// Set default language to English and include the language file
$lang_file = 'lang_en.php';
if (isset($_SESSION['lang']) && $_SESSION['lang'] == 'ar') {
    $lang_file = 'lang_ar.php';
}
include($lang_file);
?>
<!DOCTYPE html>
<html lang="<?php echo $lang['html_lang']; ?>" dir="<?php echo $lang['html_dir']; ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $lang['nav_about']; ?> - <?php echo $lang['page_title']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css">
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
            <div class="container">
                <a class="navbar-brand" href="index.php">
                    <img src="img/logo.png" alt="<?php echo $lang['navbar_brand']; ?>" width="40" height="40" class="d-inline-block align-text-top me-2"> <?php echo $lang['navbar_brand']; ?>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php"><?php echo $lang['nav_home']; ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="events.php"><?php echo $lang['nav_events']; ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="about.php"><?php echo $lang['nav_about']; ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php"><?php echo $lang['nav_contact']; ?></a>
                        </li>
                        <li class="nav-item d-flex align-items-center lang-switcher ms-lg-3">
                            <a href="about.php?lang=ar" class="nav-link p-1 mx-1"><img src="https://flagcdn.com/w40/sy.png" alt="العربية"></a>
                            <a href="about.php?lang=en" class="nav-link p-1 mx-1"><img src="https://flagcdn.com/w40/us.png" alt="English"></a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <main class="container my-5">
        <!-- عن الدليل -->
        <section class="mb-5">
            <h1 class="text-center mb-4"><?php echo $lang['about_page_title']; ?></h1>
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h2 class="text-primary"><?php echo $lang['our_vision']; ?></h2>
                    <p><?php echo $lang['vision_text']; ?></p>

                    <h2 class="text-primary mt-4"><?php echo $lang['our_mission']; ?></h2>
                    <p><?php echo $lang['mission_text']; ?></p>
                </div>
                <div class="col-md-6">
                    <img src="img/event5.jpg" alt="<?php echo $lang['about_page_title']; ?>" class="img-fluid rounded">
                </div>
            </div>
        </section>

        <!-- فريق العمل -->
        <section class="mb-5">
            <h2 class="text-center mb-4"><?php echo $lang['team_title']; ?></h2>
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="card text-center h-100">
                        <img src="img/y3.jpg" class="card-img-top rounded-circle w-50 mx-auto mt-3" alt="Team Member">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $lang['team_member_1_name']; ?></h5>
                            <p class="card-text"><?php echo $lang['team_member_1_role']; ?></p>
                            <p class="text-muted"><?php echo $lang['team_member_1_desc']; ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card text-center h-100">
                        <img src="img/y2.jpg" class="card-img-top rounded-circle w-50 mx-auto mt-3" alt="Team Member">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $lang['team_member_2_name']; ?></h5>
                            <p class="card-text"><?php echo $lang['team_member_2_role']; ?></p>
                            <p class="text-muted"><?php echo $lang['team_member_2_desc']; ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card text-center h-100">
                        <img src="img/y1.jpg" class="card-img-top rounded-circle w-50 mx-auto mt-3" alt="Team Member">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $lang['team_member_3_name']; ?></h5>
                            <p class="card-text"><?php echo $lang['team_member_3_role']; ?></p>
                            <p class="text-muted"><?php echo $lang['team_member_3_desc']; ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- السياسات -->
        <section class="mb-5">
            <h2 class="text-center mb-4"><?php echo $lang['guide_policies']; ?></h2>
            <div class="accordion" id="policiesAccordion">
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#policyOne" aria-expanded="true" aria-controls="policyOne">
                            <?php echo $lang['event_criteria']; ?>
                        </button>
                    </h2>
                    <div id="policyOne" class="accordion-collapse collapse show" data-bs-parent="#policiesAccordion">
                        <div class="accordion-body">
                            <ul>
                                <li><?php echo ($_SESSION['lang'] == 'en') ? 'The event must be open to the public or part of it.' : 'يجب أن تكون الفعالية مفتوحة للجمهور أو جزء منها.'; ?></li>
                                <li><?php echo ($_SESSION['lang'] == 'en') ? 'The information provided must be accurate and complete.' : 'يجب أن تكون المعلومات المقدمة دقيقة وكاملة.'; ?></li>
                                <li><?php echo ($_SESSION['lang'] == 'en') ? 'The event must comply with local laws and regulations.' : 'يجب أن تلتزم الفعالية بالقوانين والأنظمة المحلية.'; ?></li>
                                <li><?php echo ($_SESSION['lang'] == 'en') ? 'The event must not conflict with community values.' : 'يجب ألا تتعارض الفعالية مع القيم المجتمعية.'; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#policyTwo" aria-expanded="false" aria-controls="policyTwo">
                            <?php echo $lang['privacy_policy']; ?>
                        </button>
                    </h2>
                    <div id="policyTwo" class="accordion-collapse collapse" data-bs-parent="#policiesAccordion">
                        <div class="accordion-body">
                            <p><?php echo $lang['privacy_text']; ?></p>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#policyThree" aria-expanded="false" aria-controls="policyThree">
                            <?php echo $lang['how_to_add_event']; ?>
                        </button>
                    </h2>
                    <div id="policyThree" class="accordion-collapse collapse" data-bs-parent="#policiesAccordion">
                        <div class="accordion-body">
                            <ol>
                                <li><?php echo ($_SESSION['lang'] == 'en') ? 'Go to the "Contact Us" page.' : 'اذهب إلى صفحة "اتصل بنا".'; ?></li>
                                <li><?php echo ($_SESSION['lang'] == 'en') ? 'Fill out the form with the required information.' : 'املأ النموذج بالمعلومات المطلوبة.'; ?></li>
                                <li><?php echo ($_SESSION['lang'] == 'en') ? 'Attach a suitable image for the event.' : 'أرفق صورة مناسبة للفعالية.'; ?></li>
                                <li><?php echo ($_SESSION['lang'] == 'en') ? 'Your request will be reviewed within 48 hours.' : 'سيتم مراجعة طلبك خلال 48 ساعة.'; ?></li>
                                <li><?php echo ($_SESSION['lang'] == 'en') ? 'You will be notified of the acceptance or rejection of adding the event.' : 'سيتم إعلامك بقبول أو رفض إضافة الفعالية.'; ?></li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5><?php echo $lang['navbar_brand']; ?></h5>
                    <p><?php echo $lang['footer_platform_desc']; ?></p>
                </div>
                <div class="col-md-4">
                    <h5><?php echo $lang['footer_quick_links']; ?></h5>
                    <ul class="list-unstyled">
                        <li><a href="index.php" class="text-white"><?php echo $lang['nav_home']; ?></a></li>
                        <li><a href="events.php" class="text-white"><?php echo $lang['nav_events']; ?></a></li>
                        <li><a href="about.php" class="text-white"><?php echo $lang['nav_about']; ?></a></li>
                        <li><a href="contact.php" class="text-white"><?php echo $lang['nav_contact']; ?></a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5><?php echo $lang['footer_contact_us']; ?></h5>
                    <p><?php echo $lang['footer_email']; ?></p>
                    <p><?php echo $lang['footer_phone']; ?></p>
                    <div class="social-links">
                        <a href="#" class="text-white me-2"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="text-white me-2"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-white me-2"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <hr>
            <div class="text-center">
                <p class="mb-0"><?php echo $lang['footer_copyright']; ?></p>
                <p><?php echo $lang['footer_project_info']; ?></p>
                <p><?php echo $lang['footer_team_members']; ?></p>
            </div>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <script src="js/main.js"></script>
</body>

</html>