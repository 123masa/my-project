-- إنشاء قاعدة البيانات
CREATE DATABASE IF NOT EXISTS city_events CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE city_events;

-- إنشاء جدول الفعاليات
CREATE TABLE IF NOT EXISTS evente (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    title_en VARCHAR(255),
    description TEXT,
    description_en TEXT,
    event_date DATE NOT NULL,
    location VARCHAR(255) NOT NULL,
    location_en VARCHAR(255),
    category VARCHAR(100) NOT NULL,
    category_en VARCHAR(100),
    image VARCHAR(255) DEFAULT 'img/event1.jpg',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO evente (title, title_en, description, description_en, event_date, location, location_en, category, category_en, image) VALUES
('مهرجان الربيع السنوي', 'Annual Spring Festival', 'مهرجان رائع يحتفل بقدوم فصل الربيع مع الأنشطة والعروض المتنوعة', 'A wonderful festival celebrating the arrival of spring with various activities and shows', '2024-03-15', 'حديقة المدينة المركزية', 'Central City Park', 'مهرجان', 'Festival', 'img/event1.jpg'),
('معرض الفنون المعاصرة', 'Contemporary Art Exhibition', 'معرض يضم أعمال فنانين محليين وعالميين في الفن المعاصر', 'An exhibition featuring works by local and international artists in contemporary art', '2024-03-20', 'متحف الفنون الجميلة', 'Fine Arts Museum', 'معرض', 'Exhibition', 'img/event2.jpg'),
('حفل موسيقي كلاسيكي', 'Classical Music Concert', 'أمسية موسيقية رائعة مع أشهر المقطوعات الكلاسيكية', 'A wonderful musical evening with the most famous classical pieces', '2024-03-25', 'دار الأوبرا', 'Opera House', 'حفل موسيقي', 'Concert', 'img/event3.jpg'),
('ورشة تعلم البرمجة', 'Programming Learning Workshop', 'ورشة تدريبية لتعلم أساسيات البرمجة للمبتدئين', 'A training workshop to learn programming basics for beginners', '2024-04-01', 'مركز التقنية', 'Technology Center', 'تعليمي', 'Educational', 'img/event4.jpg'),
('بطولة كرة القدم المحلية', 'Local Football Championship', 'بطولة رياضية بين فرق الأحياء المختلفة', 'A sports tournament between different neighborhood teams', '2024-04-05', 'الملعب الرياضي', 'Sports Stadium', 'رياضي', 'Sports', 'img/event5.jpg'),
('مؤتمر التكنولوجيا', 'Technology Conference', 'مؤتمر يناقش أحدث التطورات في عالم التكنولوجيا', 'A conference discussing the latest developments in the world of technology', '2024-04-10', 'مركز المؤتمرات', 'Conference Center', 'مؤتمر', 'Conference', 'img/event6.jpg');